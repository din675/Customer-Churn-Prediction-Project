/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#e6f1ff',
          100: '#cce3ff',
          200: '#99c7ff',
          300: '#66abff',
          400: '#338fff',
          500: '#0070f3',
          600: '#005cc2',
          700: '#004591',
          800: '#002e61',
          900: '#001730',
        },
        accent: {
          50: '#e6fffc',
          100: '#ccfff9',
          200: '#99fff3',
          300: '#66ffed',
          400: '#33ffe7',
          500: '#00ccb4',
          600: '#00a390',
          700: '#007a6c',
          800: '#005248',
          900: '#002924',
        },
        warning: {
          50: '#fff1e6',
          100: '#ffe3cc',
          200: '#ffc799',
          300: '#ffab66',
          400: '#ff8f33',
          500: '#ff7846',
          600: '#cc5e38',
          700: '#99472a',
          800: '#662f1c',
          900: '#33180e',
        },
        success: {
          50: '#e6f7e6',
          100: '#ccf0cc',
          200: '#99e099',
          300: '#66d166',
          400: '#33c133',
          500: '#00b200',
          600: '#008e00',
          700: '#006b00',
          800: '#004700',
          900: '#002400',
        },
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-up': 'slideUp 0.5s ease-out',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};