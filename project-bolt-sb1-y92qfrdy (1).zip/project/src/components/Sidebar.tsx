import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  BarChart2, 
  Upload, 
  Zap, 
  Settings, 
  X, 
  Home,
  BarChart 
} from 'lucide-react';

interface SidebarProps {
  open: boolean;
  setOpen: (open: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ open, setOpen }) => {
  return (
    <>
      {/* Mobile sidebar overlay */}
      {open && (
        <div 
          className="fixed inset-0 z-40 bg-gray-600 bg-opacity-75 transition-opacity md:hidden" 
          onClick={() => setOpen(false)}
        ></div>
      )}
      
      {/* Sidebar for mobile */}
      <div 
        className={`fixed inset-y-0 left-0 flex flex-col z-40 w-64 bg-white shadow-lg transform transition ease-in-out duration-300 md:translate-x-0 md:static md:h-screen ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between h-16 flex-shrink-0 px-4 bg-primary-500">
          <div className="flex items-center">
            <BarChart className="h-8 w-8 text-white" />
            <span className="ml-2 text-xl font-bold text-white">ChurnPredictor</span>
          </div>
          <button
            className="md:hidden rounded-md text-white hover:text-gray-200 focus:outline-none focus:ring-2 focus:ring-white"
            onClick={() => setOpen(false)}
          >
            <span className="sr-only">Close sidebar</span>
            <X className="h-6 w-6" aria-hidden="true" />
          </button>
        </div>
        
        <div className="flex-1 flex flex-col overflow-y-auto pt-5 pb-4">
          <nav className="mt-5 flex-1 px-2 space-y-1">
            <NavLink
              to="/"
              className={({ isActive }) =>
                `group flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors ${
                  isActive
                    ? 'bg-primary-50 text-primary-600'
                    : 'text-gray-700 hover:bg-gray-50'
                }`
              }
            >
              <Home className="mr-3 h-5 w-5" />
              Dashboard
            </NavLink>
            
            <NavLink
              to="/predict"
              className={({ isActive }) =>
                `group flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors ${
                  isActive
                    ? 'bg-primary-50 text-primary-600'
                    : 'text-gray-700 hover:bg-gray-50'
                }`
              }
            >
              <Zap className="mr-3 h-5 w-5" />
              Prediction
            </NavLink>
            
            <NavLink
              to="/upload"
              className={({ isActive }) =>
                `group flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors ${
                  isActive
                    ? 'bg-primary-50 text-primary-600'
                    : 'text-gray-700 hover:bg-gray-50'
                }`
              }
            >
              <Upload className="mr-3 h-5 w-5" />
              Data Upload
            </NavLink>
            
            <NavLink
              to="/settings"
              className={({ isActive }) =>
                `group flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors ${
                  isActive
                    ? 'bg-primary-50 text-primary-600'
                    : 'text-gray-700 hover:bg-gray-50'
                }`
              }
            >
              <Settings className="mr-3 h-5 w-5" />
              Settings
            </NavLink>
          </nav>
        </div>
        
        <div className="flex-shrink-0 border-t border-gray-200 p-4">
          <div className="text-xs text-gray-500">
            Customer Churn Prediction
            <div className="mt-1">v0.1.0</div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;