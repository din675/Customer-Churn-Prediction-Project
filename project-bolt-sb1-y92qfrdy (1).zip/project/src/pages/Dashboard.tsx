import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { Pie, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title } from 'chart.js';
import { Users, Database, AlertTriangle, TrendingUp, ArrowRightCircle } from 'lucide-react';
import { calculateFeatureImportance } from '../utils/dataProcessing';
import type { ChartData, ChartOptions, FeatureImportance } from '../types';

// Register ChartJS components
ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title);

const Dashboard = () => {
  const { predictions, datasets, loadModel } = useData();
  const navigate = useNavigate();
  const [featureImportance, setFeatureImportance] = useState<FeatureImportance[]>([]);
  
  useEffect(() => {
    // Load the model when component mounts
    loadModel();
    
    // Calculate feature importance
    if (predictions.length > 0) {
      setFeatureImportance(calculateFeatureImportance(predictions.map(p => p.customerData)));
    }
  }, [loadModel, predictions]);
  
  // Prepare chart data
  const churnDistributionData: ChartData = {
    labels: ['Will Churn', 'Will Stay'],
    datasets: [
      {
        label: 'Customer Distribution',
        data: [
          predictions.filter(p => p.willChurn).length,
          predictions.filter(p => !p.willChurn).length
        ],
        backgroundColor: ['rgba(255, 99, 132, 0.6)', 'rgba(54, 162, 235, 0.6)'],
        borderColor: ['rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)'],
        borderWidth: 1,
      },
    ],
  };
  
  const featureImportanceData: ChartData = {
    labels: featureImportance.map(f => f.feature),
    datasets: [
      {
        label: 'Feature Importance',
        data: featureImportance.map(f => f.importance),
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  };
  
  const chartOptions: ChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Churn Analysis',
      },
    },
  };
  
  const statCards = [
    {
      title: 'Total Predictions',
      value: predictions.length,
      change: '+12%',
      icon: <Users className="h-8 w-8 text-primary-500" />,
      color: 'bg-primary-50 text-primary-500',
    },
    {
      title: 'Churn Rate',
      value: predictions.length > 0 
        ? `${Math.round((predictions.filter(p => p.willChurn).length / predictions.length) * 100)}%` 
        : '0%',
      change: '-3%',
      icon: <AlertTriangle className="h-8 w-8 text-warning-500" />,
      color: 'bg-warning-50 text-warning-500',
    },
    {
      title: 'Datasets',
      value: datasets.length,
      change: '+2',
      icon: <Database className="h-8 w-8 text-accent-500" />,
      color: 'bg-accent-50 text-accent-500',
    },
    {
      title: 'Avg. Confidence',
      value: predictions.length > 0
        ? `${Math.round(predictions.reduce((acc, p) => acc + p.confidence, 0) / predictions.length * 100)}%`
        : '0%',
      change: '+5%',
      icon: <TrendingUp className="h-8 w-8 text-success-500" />,
      color: 'bg-success-50 text-success-500',
    },
  ];
  
  return (
    <div className="space-y-6">
      {/* Welcome section */}
      <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
        <h1 className="text-2xl font-bold text-gray-900">Welcome to ChurnPredictor</h1>
        <p className="mt-1 text-gray-600">
          Use machine learning to predict customer churn and take proactive actions.
        </p>
        
        {predictions.length === 0 && (
          <div className="mt-4">
            <button 
              onClick={() => navigate('/predict')} 
              className="btn-primary"
            >
              Make your first prediction
              <ArrowRightCircle className="ml-2 h-4 w-4" />
            </button>
          </div>
        )}
      </div>
      
      {/* Stats grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
            <div className="flex items-center">
              <div className={`p-3 rounded-lg ${stat.color}`}>
                {stat.icon}
              </div>
              <div className="ml-5">
                <p className="text-sm font-medium text-gray-500 truncate">
                  {stat.title}
                </p>
                <p className="mt-1 text-3xl font-semibold text-gray-900">
                  {stat.value}
                </p>
              </div>
            </div>
            <div className="mt-4">
              <span className="text-sm font-medium text-green-600">
                {stat.change}
              </span>
              <span className="text-sm font-medium text-gray-500">
                {' '}from last period
              </span>
            </div>
          </div>
        ))}
      </div>
      
      {/* Charts */}
      {predictions.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Churn Distribution</h2>
            <div className="h-64">
              <Pie data={churnDistributionData} options={chartOptions} />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Feature Importance</h2>
            <div className="h-64">
              <Bar 
                data={featureImportanceData} 
                options={{
                  ...chartOptions,
                  plugins: {
                    ...chartOptions.plugins,
                    title: {
                      ...chartOptions.plugins.title,
                      text: 'Key Churn Factors'
                    }
                  }
                }} 
              />
            </div>
          </div>
        </div>
      )}
      
      {/* Recent predictions */}
      {predictions.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium text-gray-900">Recent Predictions</h2>
            <button 
              onClick={() => navigate('/predict')} 
              className="text-primary-500 hover:text-primary-600 font-medium text-sm flex items-center"
            >
              View All
              <ArrowRightCircle className="ml-1 h-4 w-4" />
            </button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-300">
              <thead>
                <tr>
                  <th className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">
                    Customer
                  </th>
                  <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                    Tenure
                  </th>
                  <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                    Monthly Charges
                  </th>
                  <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                    Churn Probability
                  </th>
                  <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {predictions.slice(0, 5).map((prediction, index) => (
                  <tr key={prediction.id} className="hover:bg-gray-50">
                    <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900">
                      Customer {index + 1}
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                      {prediction.customerData.tenure} months
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                      ${prediction.customerData.monthlyCharges.toFixed(2)}
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                      {Math.round(prediction.probability * 100)}%
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        prediction.willChurn 
                          ? 'bg-red-100 text-red-800' 
                          : 'bg-green-100 text-green-800'
                      }`}>
                        {prediction.willChurn ? 'Likely to Churn' : 'Likely to Stay'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;