import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import type { CustomerData, ChurnPrediction } from '../types';

const Prediction = () => {
  const { predictChurn, loading, error } = useData();
  const [formData, setFormData] = useState<CustomerData>({
    gender: 'Male',
    seniorCitizen: false,
    partner: false,
    dependents: false,
    tenure: 1,
    phoneService: true,
    multipleLines: false,
    internetService: 'Fiber optic',
    onlineSecurity: false,
    onlineBackup: false,
    deviceProtection: false,
    techSupport: false,
    streamingTV: false,
    streamingMovies: false,
    contract: 'Month-to-month',
    paperlessBilling: true,
    paymentMethod: 'Electronic check',
    monthlyCharges: 79.85,
    totalCharges: 79.85
  });
  const [prediction, setPrediction] = useState<ChurnPrediction | null>(null);
  const [formSubmitted, setFormSubmitted] = useState(false);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checkbox = e.target as HTMLInputElement;
      setFormData({
        ...formData,
        [name]: checkbox.checked
      });
    } else if (type === 'number') {
      setFormData({
        ...formData,
        [name]: parseFloat(value)
      });
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    
    try {
      const result = await predictChurn(formData);
      setPrediction(result);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      console.error('Prediction failed:', err);
    }
  };
  
  const renderPredictionResult = () => {
    if (!prediction) return null;
    
    const churnProbability = Math.round(prediction.probability * 100);
    const confidence = Math.round(prediction.confidence * 100);
    
    return (
      <div className="mb-8 animate-fade-in">
        <div className={`p-6 rounded-lg border ${
          prediction.willChurn 
            ? 'bg-red-50 border-red-200' 
            : 'bg-green-50 border-green-200'
        }`}>
          <div className="flex items-center">
            {prediction.willChurn ? (
              <AlertCircle className="h-10 w-10 text-red-500" />
            ) : (
              <CheckCircle className="h-10 w-10 text-green-500" />
            )}
            <div className="ml-4">
              <h3 className="text-lg font-medium">
                {prediction.willChurn 
                  ? 'Customer is likely to churn' 
                  : 'Customer is likely to stay'
                }
              </h3>
              <p className="text-sm mt-1">
                {prediction.willChurn
                  ? 'This customer shows a high risk of churning. Consider proactive retention measures.'
                  : 'This customer appears satisfied and is likely to remain loyal.'
                }
              </p>
            </div>
          </div>
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-white rounded-md shadow-sm border border-gray-200">
              <p className="text-sm font-medium text-gray-500">Churn Probability</p>
              <div className="mt-1 flex items-baseline">
                <p className="text-2xl font-semibold text-gray-900">{churnProbability}%</p>
              </div>
              <div className="mt-2 w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full ${
                    churnProbability > 75 ? 'bg-red-500' : 
                    churnProbability > 50 ? 'bg-warning-500' : 
                    churnProbability > 25 ? 'bg-yellow-400' : 'bg-green-500'
                  }`}
                  style={{ width: `${churnProbability}%` }}
                ></div>
              </div>
            </div>
            
            <div className="p-4 bg-white rounded-md shadow-sm border border-gray-200">
              <p className="text-sm font-medium text-gray-500">Prediction Confidence</p>
              <div className="mt-1 flex items-baseline">
                <p className="text-2xl font-semibold text-gray-900">{confidence}%</p>
              </div>
              <div className="mt-2 w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary-500 rounded-full"
                  style={{ width: `${confidence}%` }}
                ></div>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <h4 className="font-medium">Key factors influencing this prediction:</h4>
            <ul className="mt-2 space-y-1 text-sm">
              <li className="flex items-center">
                <span className="inline-block w-3 h-3 rounded-full bg-red-400 mr-2"></span>
                Contract Type: {formData.contract}
              </li>
              <li className="flex items-center">
                <span className="inline-block w-3 h-3 rounded-full bg-yellow-400 mr-2"></span>
                Monthly Charges: ${formData.monthlyCharges}
              </li>
              <li className="flex items-center">
                <span className="inline-block w-3 h-3 rounded-full bg-blue-400 mr-2"></span>
                Tenure: {formData.tenure} months
              </li>
              <li className="flex items-center">
                <span className="inline-block w-3 h-3 rounded-full bg-green-400 mr-2"></span>
                Internet Service: {formData.internetService}
              </li>
            </ul>
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      {/* Error alert */}
      {error && (
        <div className="mb-6 bg-red-50 border-l-4 border-red-500 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-500" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">
                {error}
              </p>
            </div>
          </div>
        </div>
      )}
      
      {/* Prediction result */}
      {renderPredictionResult()}
      
      {/* Prediction form */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="border-b border-gray-200 bg-gray-50 px-6 py-4">
          <h2 className="text-lg font-medium text-gray-900">Customer Information</h2>
          <p className="mt-1 text-sm text-gray-500">Enter customer details to predict churn probability</p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Basic Information */}
            <div className="space-y-4">
              <h3 className="text-md font-medium text-gray-900 border-b pb-2">Basic Information</h3>
              
              <div className="form-group">
                <label htmlFor="gender" className="form-label">Gender</label>
                <select
                  id="gender"
                  name="gender"
                  value={formData.gender}
                  onChange={handleInputChange}
                  className="form-select"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>
              
              <div className="form-group">
                <div className="flex items-center">
                  <input
                    id="seniorCitizen"
                    name="seniorCitizen"
                    type="checkbox"
                    checked={formData.seniorCitizen}
                    onChange={handleInputChange}
                    className="form-checkbox"
                  />
                  <label htmlFor="seniorCitizen" className="ml-2 text-sm text-gray-700">
                    Senior Citizen
                  </label>
                </div>
              </div>
              
              <div className="form-group">
                <div className="flex items-center">
                  <input
                    id="partner"
                    name="partner"
                    type="checkbox"
                    checked={formData.partner}
                    onChange={handleInputChange}
                    className="form-checkbox"
                  />
                  <label htmlFor="partner" className="ml-2 text-sm text-gray-700">
                    Has Partner
                  </label>
                </div>
              </div>
              
              <div className="form-group">
                <div className="flex items-center">
                  <input
                    id="dependents"
                    name="dependents"
                    type="checkbox"
                    checked={formData.dependents}
                    onChange={handleInputChange}
                    className="form-checkbox"
                  />
                  <label htmlFor="dependents" className="ml-2 text-sm text-gray-700">
                    Has Dependents
                  </label>
                </div>
              </div>
              
              <div className="form-group">
                <label htmlFor="tenure" className="form-label">Tenure (months)</label>
                <input
                  id="tenure"
                  name="tenure"
                  type="number"
                  min="0"
                  max="100"
                  value={formData.tenure}
                  onChange={handleInputChange}
                  className="form-input"
                />
              </div>
            </div>
            
            {/* Services */}
            <div className="space-y-4">
              <h3 className="text-md font-medium text-gray-900 border-b pb-2">Services</h3>
              
              <div className="form-group">
                <div className="flex items-center">
                  <input
                    id="phoneService"
                    name="phoneService"
                    type="checkbox"
                    checked={formData.phoneService}
                    onChange={handleInputChange}
                    className="form-checkbox"
                  />
                  <label htmlFor="phoneService" className="ml-2 text-sm text-gray-700">
                    Phone Service
                  </label>
                </div>
              </div>
              
              <div className="form-group">
                <div className="flex items-center">
                  <input
                    id="multipleLines"
                    name="multipleLines"
                    type="checkbox"
                    checked={formData.multipleLines}
                    onChange={handleInputChange}
                    className="form-checkbox"
                    disabled={!formData.phoneService}
                  />
                  <label htmlFor="multipleLines" className={`ml-2 text-sm ${!formData.phoneService ? 'text-gray-400' : 'text-gray-700'}`}>
                    Multiple Lines
                  </label>
                </div>
              </div>
              
              <div className="form-group">
                <label htmlFor="internetService" className="form-label">Internet Service</label>
                <select
                  id="internetService"
                  name="internetService"
                  value={formData.internetService}
                  onChange={handleInputChange}
                  className="form-select"
                >
                  <option value="No">No</option>
                  <option value="DSL">DSL</option>
                  <option value="Fiber optic">Fiber optic</option>
                </select>
              </div>
              
              <div className="form-group">
                <div className="flex items-center">
                  <input
                    id="onlineSecurity"
                    name="onlineSecurity"
                    type="checkbox"
                    checked={formData.onlineSecurity}
                    onChange={handleInputChange}
                    className="form-checkbox"
                    disabled={formData.internetService === 'No'}
                  />
                  <label htmlFor="onlineSecurity" className={`ml-2 text-sm ${formData.internetService === 'No' ? 'text-gray-400' : 'text-gray-700'}`}>
                    Online Security
                  </label>
                </div>
              </div>
              
              <div className="form-group">
                <div className="flex items-center">
                  <input
                    id="techSupport"
                    name="techSupport"
                    type="checkbox"
                    checked={formData.techSupport}
                    onChange={handleInputChange}
                    className="form-checkbox"
                    disabled={formData.internetService === 'No'}
                  />
                  <label htmlFor="techSupport" className={`ml-2 text-sm ${formData.internetService === 'No' ? 'text-gray-400' : 'text-gray-700'}`}>
                    Tech Support
                  </label>
                </div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            {/* Contract Details */}
            <div className="space-y-4">
              <h3 className="text-md font-medium text-gray-900 border-b pb-2">Contract Details</h3>
              
              <div className="form-group">
                <label htmlFor="contract" className="form-label">Contract Type</label>
                <select
                  id="contract"
                  name="contract"
                  value={formData.contract}
                  onChange={handleInputChange}
                  className="form-select"
                >
                  <option value="Month-to-month">Month-to-month</option>
                  <option value="One year">One year</option>
                  <option value="Two year">Two year</option>
                </select>
              </div>
              
              <div className="form-group">
                <div className="flex items-center">
                  <input
                    id="paperlessBilling"
                    name="paperlessBilling"
                    type="checkbox"
                    checked={formData.paperlessBilling}
                    onChange={handleInputChange}
                    className="form-checkbox"
                  />
                  <label htmlFor="paperlessBilling" className="ml-2 text-sm text-gray-700">
                    Paperless Billing
                  </label>
                </div>
              </div>
              
              <div className="form-group">
                <label htmlFor="paymentMethod" className="form-label">Payment Method</label>
                <select
                  id="paymentMethod"
                  name="paymentMethod"
                  value={formData.paymentMethod}
                  onChange={handleInputChange}
                  className="form-select"
                >
                  <option value="Electronic check">Electronic check</option>
                  <option value="Mailed check">Mailed check</option>
                  <option value="Bank transfer">Bank transfer</option>
                  <option value="Credit card">Credit card</option>
                </select>
              </div>
            </div>
            
            {/* Charges */}
            <div className="space-y-4">
              <h3 className="text-md font-medium text-gray-900 border-b pb-2">Charges</h3>
              
              <div className="form-group">
                <label htmlFor="monthlyCharges" className="form-label">Monthly Charges ($)</label>
                <input
                  id="monthlyCharges"
                  name="monthlyCharges"
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.monthlyCharges}
                  onChange={handleInputChange}
                  className="form-input"
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="totalCharges" className="form-label">Total Charges ($)</label>
                <input
                  id="totalCharges"
                  name="totalCharges"
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.totalCharges}
                  onChange={handleInputChange}
                  className="form-input"
                />
              </div>
            </div>
          </div>
          
          <div className="mt-8 flex justify-end">
            <button
              type="button"
              className="btn-secondary mr-3"
              onClick={() => {
                window.location.reload();
              }}
            >
              Reset
            </button>
            <button
              type="submit"
              className="btn-primary"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : formSubmitted && prediction ? (
                'Predict Again'
              ) : (
                'Predict Churn'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Prediction;