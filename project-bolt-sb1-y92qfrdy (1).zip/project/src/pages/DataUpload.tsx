import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useData } from '../context/DataContext';
import Papa from 'papaparse';
import { Upload, AlertCircle, CheckCircle, File, FileX, Loader2 } from 'lucide-react';
import { generateDummyData } from '../utils/dataProcessing';
import type { Dataset } from '../types';

const DataUpload = () => {
  const { addDataset, trainModel } = useData();
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'parsing' | 'training' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [parsedData, setParsedData] = useState<any[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  
  const validateData = (data: any[]) => {
    if (data.length === 0) {
      throw new Error('The uploaded file contains no data');
    }

    // Check for minimum required columns
    const requiredColumns = ['churn'];
    const missingColumns = requiredColumns.filter(col => !Object.keys(data[0]).includes(col));
    
    if (missingColumns.length > 0) {
      throw new Error(`Missing required columns: ${missingColumns.join(', ')}`);
    }

    return true;
  };

  const processUploadedData = async (data: any[]) => {
    try {
      validateData(data);
      
      // Create a new dataset object
      const newDataset: Dataset = {
        id: Date.now().toString(),
        name: 'Uploaded Dataset',
        description: 'Customer churn dataset',
        dateUploaded: new Date().toISOString(),
        rowCount: data.length,
        columns: Object.keys(data[0]),
        sampleData: data.slice(0, 5)
      };
      
      // Add the dataset
      addDataset(newDataset);
      setParsedData(data);
      
      // Start training the model
      setUploadStatus('training');
      setUploadProgress(70);
      await trainModel(data);
      
      setUploadProgress(100);
      setUploadStatus('success');
    } catch (err) {
      console.error('Error processing data:', err);
      setErrorMessage(err instanceof Error ? err.message : 'An error occurred while processing the data');
      setUploadStatus('error');
    }
  };
  
  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;
    
    setUploadStatus('parsing');
    setUploadProgress(10);
    setErrorMessage('');
    
    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      complete: async (results) => {
        try {
          setUploadProgress(50);
          
          if (results.errors.length > 0) {
            throw new Error(`Error parsing file: ${results.errors[0].message}`);
          }
          
          await processUploadedData(results.data as any[]);
        } catch (err) {
          console.error('Error processing file:', err);
          setErrorMessage(err instanceof Error ? err.message : 'An error occurred while processing the file');
          setUploadStatus('error');
        }
      },
      error: (error) => {
        console.error('Error parsing file:', error);
        setErrorMessage(`Error parsing file: ${error.message}`);
        setUploadStatus('error');
      }
    });
  }, [addDataset, trainModel]);
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.ms-excel': ['.csv'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.csv']
    }
  });
  
  const handleGenerateDummyData = async () => {
    try {
      setUploadStatus('parsing');
      setUploadProgress(25);
      setErrorMessage('');
      
      // Generate dummy data
      const data = generateDummyData(500);
      
      // Create a blob and file from the data
      const csv = Papa.unparse(data);
      const blob = new Blob([csv], { type: 'text/csv' });
      
      // Use the global File constructor
      const file = new window.File([blob], 'dummy_churn_data.csv', { type: 'text/csv' });
      
      await processUploadedData(data);
    } catch (err) {
      console.error('Error generating dummy data:', err);
      setErrorMessage(err instanceof Error ? err.message : 'An error occurred while generating dummy data');
      setUploadStatus('error');
    }
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Upload Dataset</h2>
          <p className="mt-1 text-sm text-gray-500">
            Upload a CSV file with customer data to train the churn prediction model
          </p>
        </div>
        
        <div className="p-6">
          {/* Status display */}
          {uploadStatus === 'success' && (
            <div className="mb-6 p-4 bg-green-50 border-l-4 border-green-500">
              <div className="flex">
                <div className="flex-shrink-0">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-green-700">
                    Dataset successfully uploaded and model trained!
                  </p>
                </div>
              </div>
            </div>
          )}
          
          {uploadStatus === 'error' && (
            <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-500">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-700">
                    {errorMessage || 'An error occurred during the upload process.'}
                  </p>
                </div>
              </div>
            </div>
          )}
          
          {(uploadStatus === 'parsing' || uploadStatus === 'training') && (
            <div className="mb-6 p-4 bg-blue-50 border-l-4 border-blue-500">
              <div className="flex">
                <div className="flex-shrink-0">
                  <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />
                </div>
                <div className="ml-3 flex-1">
                  <p className="text-sm text-blue-700">
                    {uploadStatus === 'parsing' ? 'Parsing your data...' : 'Training the model...'}
                  </p>
                  <div className="mt-2 upload-progress">
                    <div 
                      className="upload-progress-bar" 
                      style={{ width: `${uploadProgress}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* File upload dropzone */}
          <div 
            {...getRootProps()} 
            className={`dropzone ${isDragActive ? 'dropzone-active' : ''}`}
          >
            <input {...getInputProps()} />
            <div className="flex flex-col items-center justify-center">
              <Upload className="h-12 w-12 text-gray-400 mb-3" />
              <p className="text-lg font-medium text-gray-900">Drop your CSV file here</p>
              <p className="text-sm text-gray-500 mt-1">or click to select a file</p>
              <p className="text-xs text-gray-400 mt-3">
                The file should contain customer data with a 'churn' column
              </p>
            </div>
          </div>
          
          {/* Or use dummy data */}
          <div className="mt-6 flex items-center justify-center">
            <span className="px-4 text-sm text-gray-500">or</span>
          </div>
          
          <div className="mt-4 text-center">
            <button
              onClick={handleGenerateDummyData}
              className="btn-secondary"
              disabled={uploadStatus === 'parsing' || uploadStatus === 'training'}
            >
              Use Sample Data
            </button>
          </div>
          
          {/* Display data preview if available */}
          {parsedData.length > 0 && uploadStatus === 'success' && (
            <div className="mt-8">
              <h3 className="text-md font-medium text-gray-900 mb-2">Data Preview</h3>
              <div className="overflow-x-auto border rounded-lg">
                <table className="min-w-full divide-y divide-gray-300">
                  <thead className="bg-gray-50">
                    <tr>
                      {Object.keys(parsedData[0]).map((column) => (
                        <th
                          key={column}
                          scope="col"
                          className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          {column}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {parsedData.slice(0, 5).map((row, rowIndex) => (
                      <tr key={rowIndex}>
                        {Object.entries(row).map(([column, value], colIndex) => (
                          <td
                            key={`${rowIndex}-${colIndex}`}
                            className="px-4 py-2 text-sm text-gray-500 max-w-xs truncate"
                          >
                            {String(value)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-2 text-xs text-gray-500 text-right">
                Showing 5 of {parsedData.length} rows
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* File format information */}
      <div className="mt-6 bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">File Format Information</h2>
        </div>
        
        <div className="p-6">
          <p className="text-sm text-gray-700 mb-4">
            Your CSV file should include the following columns:
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium text-gray-900 mb-2">Required Columns:</h4>
              <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
                <li><span className="font-medium">churn</span>: Target variable (Yes/No or 1/0)</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-900 mb-2">Optional Columns:</h4>
              <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
                <li>Any numerical or categorical features</li>
                <li>The model will automatically adapt to your data structure</li>
              </ul>
            </div>
          </div>
          
          <div className="mt-4 text-sm text-gray-500">
            Note: The model will automatically handle data preprocessing and feature engineering.
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataUpload;