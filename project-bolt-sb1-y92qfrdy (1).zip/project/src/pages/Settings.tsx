import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { Sliders, Save, RotateCcw, AlertCircle } from 'lucide-react';

const Settings = () => {
  const { loadModel } = useData();
  const [resetConfirm, setResetConfirm] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);
  
  // These would be tied to actual model parameters in a full implementation
  const [settings, setSettings] = useState({
    confidenceThreshold: 0.5,
    trainingEpochs: 50,
    enableFeatureImportance: true,
    enableConfidenceScores: true,
    retentionActionsThreshold: 0.7,
    modelComplexity: 'medium',
  });
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checkbox = e.target as HTMLInputElement;
      setSettings({
        ...settings,
        [name]: checkbox.checked
      });
    } else if (type === 'range') {
      setSettings({
        ...settings,
        [name]: parseFloat(value)
      });
    } else {
      setSettings({
        ...settings,
        [name]: value
      });
    }
  };
  
  const handleSaveSettings = () => {
    // In a full implementation, this would save settings to context/localStorage
    // and potentially retrain the model with new parameters
    
    // Show success message
    const successEl = document.getElementById('settings-saved');
    if (successEl) {
      successEl.classList.remove('opacity-0');
      setTimeout(() => {
        successEl.classList.add('opacity-0');
      }, 3000);
    }
  };
  
  const handleResetModel = async () => {
    if (!resetConfirm) {
      setResetConfirm(true);
      return;
    }
    
    try {
      // Delete model from IndexedDB
      const indexedDB = window.indexedDB;
      const request = indexedDB.deleteDatabase('tensorflowjs');
      
      request.onsuccess = async () => {
        // Reinitialize the model
        await loadModel();
        setResetSuccess(true);
        setResetConfirm(false);
        
        // Clear success message after a few seconds
        setTimeout(() => {
          setResetSuccess(false);
        }, 5000);
      };
      
      request.onerror = () => {
        console.error('Error resetting model');
      };
    } catch (err) {
      console.error('Error resetting model:', err);
    }
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Model Settings</h2>
          <p className="mt-1 text-sm text-gray-500">
            Configure the churn prediction model parameters
          </p>
        </div>
        
        <div className="p-6">
          {/* Settings success message */}
          <div 
            id="settings-saved" 
            className="mb-6 p-4 bg-green-50 border-l-4 border-green-500 transition-opacity duration-500 opacity-0"
          >
            <div className="flex">
              <div className="ml-3">
                <p className="text-sm text-green-700">
                  Settings saved successfully!
                </p>
              </div>
            </div>
          </div>
          
          {/* Reset success message */}
          {resetSuccess && (
            <div className="mb-6 p-4 bg-green-50 border-l-4 border-green-500">
              <div className="flex">
                <div className="ml-3">
                  <p className="text-sm text-green-700">
                    Model reset successfully. A new model has been initialized.
                  </p>
                </div>
              </div>
            </div>
          )}
          
          <div className="space-y-6">
            {/* Prediction Settings */}
            <div>
              <h3 className="text-md font-medium text-gray-900 mb-4 flex items-center">
                <Sliders className="h-5 w-5 mr-2 text-primary-500" />
                Prediction Settings
              </h3>
              
              <div className="space-y-4">
                <div className="form-group">
                  <label htmlFor="confidenceThreshold" className="form-label">
                    Confidence Threshold: {Math.round(settings.confidenceThreshold * 100)}%
                  </label>
                  <input
                    id="confidenceThreshold"
                    name="confidenceThreshold"
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={settings.confidenceThreshold}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                  <p className="mt-1 text-xs text-gray-500">
                    Minimum confidence level required for a positive churn prediction
                  </p>
                </div>
                
                <div className="form-group">
                  <label htmlFor="retentionActionsThreshold" className="form-label">
                    Retention Actions Threshold: {Math.round(settings.retentionActionsThreshold * 100)}%
                  </label>
                  <input
                    id="retentionActionsThreshold"
                    name="retentionActionsThreshold"
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={settings.retentionActionsThreshold}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                  <p className="mt-1 text-xs text-gray-500">
                    Churn probability threshold for recommending customer retention actions
                  </p>
                </div>
                
                <div className="form-group flex items-center">
                  <input
                    id="enableConfidenceScores"
                    name="enableConfidenceScores"
                    type="checkbox"
                    checked={settings.enableConfidenceScores}
                    onChange={handleInputChange}
                    className="form-checkbox"
                  />
                  <label htmlFor="enableConfidenceScores" className="ml-2 text-sm text-gray-700">
                    Show confidence scores in predictions
                  </label>
                </div>
              </div>
            </div>
            
            {/* Model Training Settings */}
            <div>
              <h3 className="text-md font-medium text-gray-900 mb-4 flex items-center">
                <RotateCcw className="h-5 w-5 mr-2 text-primary-500" />
                Model Training Settings
              </h3>
              
              <div className="space-y-4">
                <div className="form-group">
                  <label htmlFor="trainingEpochs" className="form-label">
                    Training Epochs: {settings.trainingEpochs}
                  </label>
                  <input
                    id="trainingEpochs"
                    name="trainingEpochs"
                    type="range"
                    min="10"
                    max="100"
                    step="10"
                    value={settings.trainingEpochs}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                  <p className="mt-1 text-xs text-gray-500">
                    Number of training cycles (higher values may improve accuracy but take longer)
                  </p>
                </div>
                
                <div className="form-group">
                  <label htmlFor="modelComplexity" className="form-label">Model Complexity</label>
                  <select
                    id="modelComplexity"
                    name="modelComplexity"
                    value={settings.modelComplexity}
                    onChange={handleInputChange}
                    className="form-select"
                  >
                    <option value="simple">Simple (Faster)</option>
                    <option value="medium">Medium (Balanced)</option>
                    <option value="complex">Complex (More Accurate)</option>
                  </select>
                  <p className="mt-1 text-xs text-gray-500">
                    Determines the neural network architecture complexity
                  </p>
                </div>
                
                <div className="form-group flex items-center">
                  <input
                    id="enableFeatureImportance"
                    name="enableFeatureImportance"
                    type="checkbox"
                    checked={settings.enableFeatureImportance}
                    onChange={handleInputChange}
                    className="form-checkbox"
                  />
                  <label htmlFor="enableFeatureImportance" className="ml-2 text-sm text-gray-700">
                    Calculate feature importance
                  </label>
                </div>
              </div>
            </div>
            
            {/* Actions */}
            <div className="pt-4 border-t border-gray-200 flex justify-between">
              <div>
                <button
                  type="button"
                  className={`inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium ${
                    resetConfirm 
                      ? 'text-white bg-red-600 hover:bg-red-700 focus:ring-red-500'
                      : 'text-red-700 bg-red-100 hover:bg-red-200 focus:ring-red-500'
                  }`}
                  onClick={handleResetModel}
                >
                  <RotateCcw className="mr-2 h-4 w-4" />
                  {resetConfirm ? 'Confirm Reset' : 'Reset Model'}
                </button>
                
                {resetConfirm && (
                  <p className="mt-2 text-xs text-red-500 flex items-center">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    This will delete the current model and all training data
                  </p>
                )}
              </div>
              
              <button
                type="button"
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-500 hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                onClick={handleSaveSettings}
              >
                <Save className="mr-2 h-4 w-4" />
                Save Settings
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Advanced Settings */}
      <div className="mt-6 bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Advanced Settings</h2>
        </div>
        
        <div className="p-6">
          <p className="text-sm text-gray-500 mb-4">
            These settings are for advanced users and require model retraining to take effect.
          </p>
          
          <div className="space-y-4">
            <div className="form-group">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Model Architecture Visualization
              </label>
              <div className="border border-gray-300 rounded-md p-4 bg-gray-50 text-sm text-gray-500">
                <div className="space-y-2">
                  <div className="p-2 border border-gray-300 rounded bg-white text-center">
                    Input Layer (8 features)
                  </div>
                  <div className="flex justify-center">
                    <div className="w-0 h-6 border-l border-gray-300"></div>
                  </div>
                  <div className="p-2 border border-gray-300 rounded bg-white text-center">
                    Hidden Layer 1 (16 units, ReLU)
                  </div>
                  <div className="flex justify-center">
                    <div className="w-0 h-6 border-l border-gray-300"></div>
                  </div>
                  <div className="p-2 border border-gray-300 rounded bg-white text-center">
                    Hidden Layer 2 (8 units, ReLU)
                  </div>
                  <div className="flex justify-center">
                    <div className="w-0 h-6 border-l border-gray-300"></div>
                  </div>
                  <div className="p-2 border border-gray-300 rounded bg-white text-center">
                    Output Layer (1 unit, Sigmoid)
                  </div>
                </div>
              </div>
            </div>
            
            <div className="form-group">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Data Preprocessing
              </label>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input
                    id="normalizeData"
                    name="normalizeData"
                    type="checkbox"
                    checked={true}
                    className="form-checkbox"
                    disabled
                  />
                  <label htmlFor="normalizeData" className="ml-2 text-sm text-gray-700">
                    Normalize numerical features
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="oneHotEncoding"
                    name="oneHotEncoding"
                    type="checkbox"
                    checked={true}
                    className="form-checkbox"
                    disabled
                  />
                  <label htmlFor="oneHotEncoding" className="ml-2 text-sm text-gray-700">
                    One-hot encode categorical features
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="handleMissingValues"
                    name="handleMissingValues"
                    type="checkbox"
                    checked={true}
                    className="form-checkbox"
                    disabled
                  />
                  <label htmlFor="handleMissingValues" className="ml-2 text-sm text-gray-700">
                    Handle missing values automatically
                  </label>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-4 p-3 bg-yellow-50 rounded border border-yellow-200 text-sm text-yellow-800">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-yellow-600 mr-2" />
              <div>
                <p className="font-medium">Advanced settings are read-only in this version</p>
                <p className="mt-1">These settings can only be changed in the full version of the application.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;