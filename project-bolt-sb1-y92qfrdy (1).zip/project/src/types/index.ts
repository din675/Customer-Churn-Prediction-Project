export interface CustomerData {
  id?: string;
  gender: 'Male' | 'Female';
  seniorCitizen: boolean;
  partner: boolean;
  dependents: boolean;
  tenure: number;
  phoneService: boolean;
  multipleLines: boolean;
  internetService: 'No' | 'DSL' | 'Fiber optic';
  onlineSecurity: boolean;
  onlineBackup: boolean;
  deviceProtection: boolean;
  techSupport: boolean;
  streamingTV: boolean;
  streamingMovies: boolean;
  contract: 'Month-to-month' | 'One year' | 'Two year';
  paperlessBilling: boolean;
  paymentMethod: 'Electronic check' | 'Mailed check' | 'Bank transfer' | 'Credit card';
  monthlyCharges: number;
  totalCharges: number;
}

export interface ChurnPrediction {
  id: string;
  timestamp: string;
  customerData: CustomerData;
  probability: number;
  willChurn: boolean;
  confidence: number;
}

export interface Dataset {
  id: string;
  name: string;
  description: string;
  dateUploaded: string;
  rowCount: number;
  columns: string[];
  sampleData: any[];
  file?: File;
}

export interface FeatureImportance {
  feature: string;
  importance: number;
}

export type ChartData = {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor: string[];
    borderColor: string[];
    borderWidth: number;
  }[];
};

export type ChartOptions = {
  responsive: boolean;
  maintainAspectRatio: boolean;
  plugins: {
    legend: {
      position: 'top' | 'bottom' | 'left' | 'right';
    };
    title: {
      display: boolean;
      text: string;
    };
  };
};