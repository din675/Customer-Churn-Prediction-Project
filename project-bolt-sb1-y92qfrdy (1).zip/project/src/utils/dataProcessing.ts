/**
 * Process raw data for machine learning
 */
export const processData = (data: any[]) => {
  // Define features we want to use for prediction
  const inputFeatures = [
    'tenure', 
    'monthlyCharges', 
    'totalCharges',
    'gender',
    'partner',
    'dependents',
    'phoneService',
    'internetService'
  ];
  
  const outputLabel = 'churn';
  
  // Pre-process the data
  const processedData = data.map(row => {
    // Handle any data conversion needed
    const processedRow: any = { ...row };
    
    // Convert string values to numbers where appropriate
    if (typeof processedRow.tenure === 'string') {
      processedRow.tenure = parseFloat(processedRow.tenure);
    }
    
    if (typeof processedRow.monthlyCharges === 'string') {
      processedRow.monthlyCharges = parseFloat(processedRow.monthlyCharges);
    }
    
    if (typeof processedRow.totalCharges === 'string') {
      // Handle empty strings or non-numeric values
      processedRow.totalCharges = processedRow.totalCharges.trim() === '' 
        ? 0 
        : parseFloat(processedRow.totalCharges);
    }
    
    // Convert categorical to binary
    processedRow.gender = processedRow.gender === 'Male' ? 1 : 0;
    processedRow.partner = processedRow.partner === 'Yes' ? 1 : 0;
    processedRow.dependents = processedRow.dependents === 'Yes' ? 1 : 0;
    processedRow.phoneService = processedRow.phoneService === 'Yes' ? 1 : 0;
    
    // Convert internet service to ordinal
    if (processedRow.internetService === 'Fiber optic') {
      processedRow.internetService = 1;
    } else if (processedRow.internetService === 'DSL') {
      processedRow.internetService = 0.5;
    } else {
      processedRow.internetService = 0;
    }
    
    // Convert churn label
    processedRow.churn = processedRow.churn === 'Yes' ? 1 : 0;
    
    return processedRow;
  });
  
  return { processedData, inputFeatures, outputLabel };
};

/**
 * Normalize the data for better model performance
 */
export const normalizeData = (
  data: any[], 
  inputFeatures: string[], 
  outputLabel: string
) => {
  // Extract inputs and labels
  const inputs = data.map(row => 
    inputFeatures.map(feature => row[feature])
  );
  
  const labels = data.map(row => [row[outputLabel]]);
  
  // Find min and max for normalization
  const mins = Array(inputFeatures.length).fill(Number.MAX_VALUE);
  const maxs = Array(inputFeatures.length).fill(Number.MIN_VALUE);
  
  // Calculate min and max for each feature
  inputs.forEach(row => {
    row.forEach((value, i) => {
      if (value < mins[i]) mins[i] = value;
      if (value > maxs[i]) maxs[i] = value;
    });
  });
  
  // Normalize inputs
  const normalizedInputs = inputs.map(row => 
    row.map((value, i) => {
      // If max equals min, avoid division by zero
      return maxs[i] === mins[i] 
        ? 0 
        : (value - mins[i]) / (maxs[i] - mins[i]);
    })
  );
  
  return { normalizedInputs, normalizedLabels: labels };
};

/**
 * Generate dummy data for testing
 */
export const generateDummyData = (count: number = 100) => {
  const dummyData = [];
  
  for (let i = 0; i < count; i++) {
    dummyData.push({
      gender: Math.random() > 0.5 ? 'Male' : 'Female',
      seniorCitizen: Math.random() > 0.7,
      partner: Math.random() > 0.5,
      dependents: Math.random() > 0.7,
      tenure: Math.floor(Math.random() * 72), // 0-72 months
      phoneService: Math.random() > 0.1, // Most have phone service
      multipleLines: Math.random() > 0.5,
      internetService: ['No', 'DSL', 'Fiber optic'][Math.floor(Math.random() * 3)],
      onlineSecurity: Math.random() > 0.5,
      onlineBackup: Math.random() > 0.5,
      deviceProtection: Math.random() > 0.5,
      techSupport: Math.random() > 0.5,
      streamingTV: Math.random() > 0.5,
      streamingMovies: Math.random() > 0.5,
      contract: ['Month-to-month', 'One year', 'Two year'][Math.floor(Math.random() * 3)],
      paperlessBilling: Math.random() > 0.3, // Most have paperless billing
      paymentMethod: ['Electronic check', 'Mailed check', 'Bank transfer', 'Credit card'][Math.floor(Math.random() * 4)],
      monthlyCharges: Math.floor(Math.random() * 120) + 20, // $20-$140
      totalCharges: Math.floor(Math.random() * 8000) + 500, // $500-$8500
      churn: Math.random() > 0.7 ? 'Yes' : 'No' // 30% churn rate
    });
  }
  
  return dummyData;
};

/**
 * Calculate feature importance (simplified version)
 */
export const calculateFeatureImportance = (data: any[]): { feature: string; importance: number }[] => {
  // This is a simplified placeholder. In a real application, you would use
  // permutation importance, SHAP values, or model-specific importance values
  
  // For demonstration, return dummy feature importance
  return [
    { feature: 'Contract Type', importance: 0.25 },
    { feature: 'Monthly Charges', importance: 0.20 },
    { feature: 'Tenure', importance: 0.18 },
    { feature: 'Internet Service', importance: 0.15 },
    { feature: 'Tech Support', importance: 0.10 },
    { feature: 'Payment Method', importance: 0.07 },
    { feature: 'Senior Citizen', importance: 0.03 },
    { feature: 'Gender', importance: 0.02 },
  ];
};