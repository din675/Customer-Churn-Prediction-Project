import React, { createContext, useContext, useState, useEffect } from 'react';
import * as tf from '@tensorflow/tfjs';
import { processData, normalizeData } from '../utils/dataProcessing';
import type { Dataset, ChurnPrediction, CustomerData } from '../types';

interface DataContextProps {
  datasets: Dataset[];
  currentDataset: Dataset | null;
  predictions: ChurnPrediction[];
  loading: boolean;
  error: string | null;
  model: tf.LayersModel | null;
  addDataset: (dataset: Dataset) => void;
  setCurrentDataset: (id: string) => void;
  predictChurn: (customerData: CustomerData) => Promise<ChurnPrediction>;
  loadModel: () => Promise<void>;
  trainModel: (data: any[]) => Promise<void>;
}

const DataContext = createContext<DataContextProps | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [currentDataset, setCurrentDataset] = useState<Dataset | null>(null);
  const [predictions, setPredictions] = useState<ChurnPrediction[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [model, setModel] = useState<tf.LayersModel | null>(null);
  
  // Load previously saved data from localStorage
  useEffect(() => {
    try {
      const savedDatasets = localStorage.getItem('churn-datasets');
      if (savedDatasets) {
        setDatasets(JSON.parse(savedDatasets));
      }
      
      const savedPredictions = localStorage.getItem('churn-predictions');
      if (savedPredictions) {
        setPredictions(JSON.parse(savedPredictions));
      }
    } catch (err) {
      console.error('Error loading data from localStorage:', err);
    }
  }, []);
  
  // Save data to localStorage when it changes
  useEffect(() => {
    if (datasets.length > 0) {
      localStorage.setItem('churn-datasets', JSON.stringify(datasets));
    }
  }, [datasets]);
  
  useEffect(() => {
    if (predictions.length > 0) {
      localStorage.setItem('churn-predictions', JSON.stringify(predictions));
    }
  }, [predictions]);
  
  const addDataset = (dataset: Dataset) => {
    setDatasets(prev => [...prev, dataset]);
    if (!currentDataset) {
      setCurrentDataset(dataset);
    }
  };
  
  const selectDataset = (id: string) => {
    const selected = datasets.find(d => d.id === id) || null;
    setCurrentDataset(selected);
  };
  
  // Load or create a TensorFlow.js model
  const loadModel = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Try to load the model from IndexedDB
      try {
        const loadedModel = await tf.loadLayersModel('indexeddb://churn-prediction-model');
        setModel(loadedModel);
        console.log('Model loaded from storage');
        setLoading(false);
        return;
      } catch (err) {
        console.log('No saved model found, creating a new one');
      }
      
      // Create a new model
      const newModel = tf.sequential();
      
      // Simple model with two dense layers
      newModel.add(tf.layers.dense({
        inputShape: [8], // Assuming 8 input features
        units: 16,
        activation: 'relu'
      }));
      
      newModel.add(tf.layers.dense({
        units: 8,
        activation: 'relu'
      }));
      
      newModel.add(tf.layers.dense({
        units: 1,
        activation: 'sigmoid'
      }));
      
      // Compile the model
      newModel.compile({
        optimizer: tf.train.adam(),
        loss: 'binaryCrossentropy',
        metrics: ['accuracy']
      });
      
      setModel(newModel);
      setLoading(false);
    } catch (err) {
      setError('Failed to load or create model');
      setLoading(false);
      console.error('Error loading/creating model:', err);
    }
  };
  
  // Train the model with the uploaded dataset
  const trainModel = async (data: any[]) => {
    if (!model || !data.length) return;
    
    try {
      setLoading(true);
      setError(null);
      
      // Process and normalize the data
      const { processedData, inputFeatures, outputLabel } = processData(data);
      const { normalizedInputs, normalizedLabels } = normalizeData(processedData, inputFeatures, outputLabel);
      
      // Convert to tensors
      const xs = tf.tensor2d(normalizedInputs);
      const ys = tf.tensor2d(normalizedLabels);
      
      // Train the model
      await model.fit(xs, ys, {
        epochs: 50,
        batchSize: 32,
        validationSplit: 0.2,
        callbacks: {
          onEpochEnd: (epoch, logs) => {
            console.log(`Epoch ${epoch}: loss = ${logs?.loss}, accuracy = ${logs?.acc}`);
          }
        }
      });
      
      // Save the model to IndexedDB
      await model.save('indexeddb://churn-prediction-model');
      
      // Clean up tensors
      xs.dispose();
      ys.dispose();
      
      setLoading(false);
    } catch (err) {
      setError('Failed to train model');
      setLoading(false);
      console.error('Error training model:', err);
    }
  };
  
  // Predict customer churn
  const predictChurn = async (customerData: CustomerData): Promise<ChurnPrediction> => {
    if (!model) {
      throw new Error('Model not loaded. Please load or train a model first.');
    }
    
    try {
      setLoading(true);
      
      // Normalize the input data
      const normalizedInput = [
        customerData.tenure / 100, // Assuming max tenure is 100
        customerData.monthlyCharges / 200, // Assuming max monthly charge is $200
        customerData.totalCharges / 10000, // Assuming max total charge is $10000
        customerData.gender === 'Male' ? 1 : 0,
        customerData.partner ? 1 : 0,
        customerData.dependents ? 1 : 0,
        customerData.phoneService ? 1 : 0,
        customerData.internetService === 'Fiber optic' ? 1 : customerData.internetService === 'DSL' ? 0.5 : 0
      ];
      
      // Convert to tensor and predict
      const inputTensor = tf.tensor2d([normalizedInput]);
      const predictionTensor = model.predict(inputTensor) as tf.Tensor;
      const predictionValue = await predictionTensor.dataSync()[0];
      
      // Clean up tensors
      inputTensor.dispose();
      predictionTensor.dispose();
      
      // Create prediction object
      const prediction: ChurnPrediction = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        customerData,
        probability: predictionValue,
        willChurn: predictionValue > 0.5,
        confidence: Math.abs(predictionValue - 0.5) * 2 // Scale to 0-1 range
      };
      
      // Add to predictions list
      setPredictions(prev => [prediction, ...prev]);
      
      setLoading(false);
      return prediction;
    } catch (err) {
      setError('Failed to make prediction');
      setLoading(false);
      console.error('Error predicting churn:', err);
      throw err;
    }
  };
  
  const value = {
    datasets,
    currentDataset,
    predictions,
    loading,
    error,
    model,
    addDataset,
    setCurrentDataset: selectDataset,
    predictChurn,
    loadModel,
    trainModel
  };
  
  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};